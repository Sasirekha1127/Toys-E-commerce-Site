import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import pg from 'pg';

const { Pool } = pg;

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'local_db',
  password: 'sasi',
  port: 5432,
});

app.get('/', (req, res) => {
  res.send('Server running');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});