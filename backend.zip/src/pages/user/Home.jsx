import React from 'react';
import { useState } from 'react';
import BannerCarousel from '../../components/user/BannerCarousel';
import ProductCarousel from '../../components/user/ProductCarousel';
import Header from "../../components/user/UserHeader";
import { softToys, educationalToys, electronicToys } from '../../data/user';
import { ShieldCheck, Truck, RotateCcw, HeadphonesIcon, Star, Sparkles } from 'lucide-react';


const features = [
  { icon: <ShieldCheck size={22} />, title: 'Safe & Certified', desc: 'All toys meet international safety standards', color: 'bg-green-100 text-green-600' },
  { icon: <Truck size={22} />, title: 'Free Shipping', desc: 'On all orders above $35', color: 'bg-orange-100 text-orange-600' },
  { icon: <RotateCcw size={22} />, title: 'Easy Returns', desc: '30-day hassle-free returns', color: 'bg-purple-100 text-purple-600' },
  { icon: <HeadphonesIcon size={22} />, title: '24/7 Support', desc: 'Always here when you need us', color: 'bg-orange-100 text-orange-600' },
];

const categories = [
  { label: 'Soft Toys', color: 'from-pink-400 to-rose-300', bg: 'bg-pink-50', count: softToys.length },
  { label: 'Educational', color: 'from-orange-400 to-cyan-300', bg: 'bg-orange-50', count: educationalToys.length },
  { label: 'Electronic', color: 'from-violet-400 to-purple-300', bg: 'bg-violet-50', count: electronicToys.length },
  { label: 'Building Sets', color: 'from-amber-400 to-orange-300', bg: 'bg-amber-50', count: 12 },
  { label: 'Outdoor Play', color: 'from-green-400 to-emerald-300', bg: 'bg-green-50', count: 8 },
  { label: 'Art & Craft', color: 'from-orange-400 to-amber-300', bg: 'bg-orange-50', count: 15 },
];

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');

  const handleSearch = (value) => setSearchTerm(value);
  const handleCategoryChange = (cat) => setSelectedCategory(cat);

  const filterProducts = (products) =>
    products.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategory = selectedCategory === 'All Categories' || p.category === selectedCategory;
      return matchSearch && matchCategory;
    });
  return (
    <div className="page-enter">
      <Header
        onSearch={handleSearch}
        onCategoryChange={handleCategoryChange}
      />

      {/* Hero Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-2">
        <BannerCarousel />
      </section>



      {/* Category quick links */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Section Header */}
        <div className="flex items-center gap-2 mb-6">
          <Sparkles size={20} className="text-orange-400" />
          <h2 className="font-display text-2xl md:text-3xl text-gray-800">Shop by Category</h2>
        </div>

        {/* Category Buttons */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {categories.map((cat, i) => (
            <button
              key={i}
              onClick={() => {
                const id = cat.label.toLowerCase().replace(/\s/g, '-') + '-toys';
                const el = document.getElementById(id);
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className={`${cat.bg} rounded-2xl p-4 flex flex-col items-center gap-2 
              hover:-translate-y-1 hover:shadow-lg hover:shadow-orange-300 transition-all duration-300 
              border border-transparent hover:border-orange-200 group`}
                >

              {/* Label */}
              <span className="font-bold text-sm text-gray-800 text-center leading-tight group-hover:text-orange-600 transition-colors duration-300">
                {cat.label}
              </span>

              {/* Count */}
              <span className="text-[10px] text-gray-500 font-medium group-hover:text-orange-400 transition-colors duration-300">
                {cat.count} items
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Product sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Divider */}
        <div className="flex items-center gap-4 py-4">
          <div className="flex-1 h-px bg-orange-100" />
          <span className="text-orange-300 text-sm font-bold tracking-wider"> OUR COLLECTION </span>
          <div className="flex-1 h-px bg-orange-100" />
        </div>

        <div id="soft-toys">
          <ProductCarousel
            products={filterProducts(softToys)}
            title="Soft Toys"
            icon="🧸"
            color="orange"
          />
        </div>

        {/* Mid-page banner */}
        <div className="my-6 rounded-3xl bg-gradient-to-r from-amber-400 to-orange-500 p-8 flex items-center justify-between overflow-hidden relative shadow-xl">
          <div className="relative z-10">
            <p className="text-white/80 text-sm font-bold uppercase tracking-widest mb-1">Limited Time</p>
            <h3 className="font-display text-3xl md:text-4xl text-white mb-2">Up to 40% OFF</h3>
            <p className="text-white/90 text-base mb-4">On selected educational & STEM toys this week only!</p>
            <button
              className="bg-white text-orange-600 font-bold px-6 py-2.5 rounded-xl hover:bg-orange-50 transition-all hover:scale-105 shadow-lg"
              onClick={() => document.getElementById('educational-toys')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Shop the Sale →
            </button>
          </div>
          <div className="absolute right-4 md:right-16 text-[100px] md:text-[140px] opacity-20 select-none"></div>
          <div className="absolute -bottom-6 -right-6 w-40 h-40 border-4 border-white/20 rounded-full" />
          <div className="absolute -bottom-10 -right-10 w-60 h-60 border-4 border-white/10 rounded-full" />
        </div>

        <div id="educational-toys">
          <ProductCarousel
            products={filterProducts(educationalToys)}
            title="Educational Toys"
            icon="🎓"
            color="orange"
          />
        </div>

        <div id="electronic-toys">
          <ProductCarousel
            products={filterProducts(electronicToys)}
            title="Electronic Toys"
            icon="⚡"
            color="orange"
          />
        </div>
      </div>

      {/* Testimonials */}
      <section className="bg-gradient-to-br from-orange-50 to-amber-50 py-16 mt-10 dots-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl md:text-4xl text-orange-800 mb-2">Happy Little Customers </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Sarah M.", kid: "Mom of 3", review: "ToyLand is our family's go-to! Quality is incredible and my kids absolutely love every single toy we've ordered.", rating: 5, avatar: "👩‍👧‍👦" },
              { name: "James R.", kid: "Dad of twins", review: "Fast shipping, amazing packaging, and the educational toys have genuinely helped my kids learn faster. Highly recommend!", rating: 5, avatar: "👨‍👦‍👦" },
              { name: "Priya K.", kid: "Mom of 1", review: "The soft toys are SO soft and the quality is premium. My daughter sleeps with her bunny every night! Worth every penny.", rating: 5, avatar: "👩‍👧" },
            ].map((t, i) => (
              <div key={i} className="bg-white rounded-3xl p-6 shadow-toy hover:shadow-toy-hover transition-all hover:-translate-y-1">
                <div className="flex gap-1 mb-3">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} size={16} className="text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4 font-body italic">"{t.review}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center text-xl">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="font-bold text-gray-800 text-sm">{t.name}</p>
                    <p className="text-xs text-gray-400">{t.kid}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Features strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {features.map((f, i) => (
            <div
              key={i}
              className="flex items-start gap-3 bg-white rounded-2xl p-4 shadow-toy transition-all 
                   hover:shadow-lg hover:shadow-orange-300 hover:-translate-y-1"
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center flex-none 
                      ${f.color} transition-all duration-300 group-hover:bg-orange-500`}
              >
                {f.icon}
              </div>
              <div>
                <p className="font-bold text-gray-800 text-sm group-hover:text-orange-600 transition-colors duration-300">
                  {f.title}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
