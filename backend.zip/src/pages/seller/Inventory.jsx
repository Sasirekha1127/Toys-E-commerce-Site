import React, { useState } from 'react';
import { AlertTriangle, PackageX, CheckCircle, RefreshCw } from 'lucide-react';
import { sellerProducts } from '../../data/seller/index.js';

function fmt(n) { return new Intl.NumberFormat('en-IN').format(n); }

function StatusBadge({ status }) {
  const map = { Active: 'badge-green', 'Low Stock': 'badge-orange', 'Out of Stock': 'badge-red' };
  return <span className={`badge ${map[status] || 'badge-gray'}`}>{status}</span>;
}

function StockBar({ stock, max = 150 }) {
  const pct = Math.min((stock / max) * 100, 100);
  const color = stock === 0 ? 'bg-red-400' : stock <= 5 ? 'bg-amber-400' : 'bg-emerald-400';
  return (
    <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
      <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function SellerInventory() {
  const [products, setProducts] = useState(sellerProducts);
  const [restocked, setRestocked] = useState({});

  const outOfStock = products.filter((p) => p.stock === 0);
  const lowStock = products.filter((p) => p.stock > 0 && p.stock <= 5);
  const healthy = products.filter((p) => p.stock > 5);

  const handleRestock = (id) => {
    setProducts((prev) =>
      prev.map((p) => p.id === id ? { ...p, stock: p.stock + 50, status: 'Active' } : p)
    );
    setRestocked((r) => ({ ...r, [id]: true }));
    setTimeout(() => setRestocked((r) => { const n = { ...r }; delete n[id]; return n; }), 2000);
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-5">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Inventory</h2>
        <p className="text-sm text-gray-500">Monitor stock levels and restock items</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center flex-none">
            <CheckCircle size={20} className="text-emerald-500" />
          </div>
          <div>
            <p className="text-xl font-bold text-gray-900">{healthy.length}</p>
            <p className="text-xs text-gray-400">In Stock</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center flex-none">
            <AlertTriangle size={20} className="text-amber-500" />
          </div>
          <div>
            <p className="text-xl font-bold text-gray-900">{lowStock.length}</p>
            <p className="text-xs text-gray-400">Low Stock</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center flex-none">
            <PackageX size={20} className="text-red-500" />
          </div>
          <div>
            <p className="text-xl font-bold text-gray-900">{outOfStock.length}</p>
            <p className="text-xs text-gray-400">Out of Stock</p>
          </div>
        </div>
      </div>

      {/* Alerts section */}
      {(outOfStock.length > 0 || lowStock.length > 0) && (
        <div className="card p-5 border-l-4 border-amber-400">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={18} className="text-amber-500" />
            <p className="font-semibold text-gray-800">Stock Alerts</p>
            <span className="badge badge-orange">{outOfStock.length + lowStock.length} items</span>
          </div>
          <div className="space-y-3">
            {[...outOfStock, ...lowStock].map((item) => (
              <div key={item.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-10 h-10 rounded-xl object-cover bg-gray-100 flex-none"
                  onError={(e) => { e.target.style.display='none'; }}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800">{item.name}</p>
                  <p className="text-xs text-gray-400">{item.category} · {item.stock} units left</p>
                  <StockBar stock={item.stock} />
                </div>
                <StatusBadge status={item.status} />
                <button
                  onClick={() => handleRestock(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${restocked[item.id] ? 'bg-emerald-500 text-white' : 'bg-orange-500 text-white hover:bg-orange-600'}`}
                >
                  <RefreshCw size={12} className={restocked[item.id] ? '' : ''} />
                  {restocked[item.id] ? 'Restocked!' : 'Restock'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Full inventory table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <p className="section-title">All Products Stock</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50/60 border-b border-gray-100">
              <tr>
                <th className="table-th">Product</th>
                <th className="table-th hidden md:table-cell">Category</th>
                <th className="table-th">Stock</th>
                <th className="table-th hidden sm:table-cell">Bar</th>
                <th className="table-th">Status</th>
                <th className="table-th">Action</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="table-row">
                  <td className="table-td">
                    <div className="flex items-center gap-3">
                      <img src={p.image} alt={p.name} className="w-9 h-9 rounded-xl object-cover bg-gray-100 flex-none" onError={(e) => { e.target.style.display='none'; }} />
                      <p className="font-medium text-gray-800 truncate max-w-[140px]">{p.name}</p>
                    </div>
                  </td>
                  <td className="table-td hidden md:table-cell text-gray-500">{p.category}</td>
                  <td className="table-td font-semibold text-gray-800">{p.stock} units</td>
                  <td className="table-td hidden sm:table-cell w-32"><StockBar stock={p.stock} /></td>
                  <td className="table-td"><StatusBadge status={p.status} /></td>
                  <td className="table-td">
                    {(p.status === 'Low Stock' || p.status === 'Out of Stock') ? (
                      <button
                        onClick={() => handleRestock(p.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${restocked[p.id] ? 'bg-emerald-500 text-white' : 'bg-orange-50 text-orange-600 hover:bg-orange-100'}`}
                      >
                        <RefreshCw size={12} />
                        {restocked[p.id] ? 'Done!' : 'Restock'}
                      </button>
                    ) : (
                      <span className="text-xs text-gray-400">Good</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
