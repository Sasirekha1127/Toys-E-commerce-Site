import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { sellerOrders } from '../../data/seller/index.js';

function fmt(n) { return new Intl.NumberFormat('en-IN').format(n); }

function StatusBadge({ status }) {
  const map = {
    Delivered: 'badge-green',
    Shipped: 'badge-blue',
    Pending: 'badge-orange',
    Processing: 'badge-gray',
    Cancelled: 'badge-red',
    Paid: 'badge-green',
    Refunded: 'badge-gray',
  };
  return <span className={`badge ${map[status] || 'badge-gray'}`}>{status}</span>;
}

const statusOptions = ['All', 'Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

export default function SellerOrders() {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');

  const filtered = sellerOrders.filter((o) => {
    const matchSearch =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.customer.toLowerCase().includes(search.toLowerCase()) ||
      o.product.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'All' || o.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const totalRevenue = filtered.reduce((sum, o) => o.payment === 'Paid' ? sum + o.amount : sum, 0);

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-gray-900">Orders</h2>
        <p className="text-sm text-gray-500">{sellerOrders.length} total orders · ₹{fmt(totalRevenue)} revenue shown</p>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="input pl-9"
            placeholder="Search by order ID, customer, product..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {statusOptions.map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filterStatus === s ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-orange-50 hover:text-orange-600'}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50/60 border-b border-gray-100">
              <tr>
                <th className="table-th">Order ID</th>
                <th className="table-th">Customer</th>
                <th className="table-th hidden md:table-cell">Product</th>
                <th className="table-th">Amount</th>
                <th className="table-th hidden sm:table-cell">Payment</th>
                <th className="table-th">Status</th>
                <th className="table-th hidden lg:table-cell">Date</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o.id} className="table-row">
                  <td className="table-td font-mono text-xs text-orange-600 font-semibold">{o.id}</td>
                  <td className="table-td">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-brand-grad flex items-center justify-center text-white text-[10px] font-bold flex-none">
                        {o.customer.charAt(0)}
                      </div>
                      <span className="font-medium text-gray-800">{o.customer}</span>
                    </div>
                  </td>
                  <td className="table-td hidden md:table-cell text-gray-500">{o.product}</td>
                  <td className="table-td font-semibold text-gray-800">₹{fmt(o.amount)}</td>
                  <td className="table-td hidden sm:table-cell"><StatusBadge status={o.payment} /></td>
                  <td className="table-td"><StatusBadge status={o.status} /></td>
                  <td className="table-td hidden lg:table-cell text-gray-400 text-xs">{o.date}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="table-td text-center text-gray-400 py-10">No orders found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
