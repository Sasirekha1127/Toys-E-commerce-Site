const softToys = [
  {
    id: "st-001",
    name: "Teddy Bear",
    image: "https://cdn.bloomsflora.com/uploads/product/bloomsflora/DEC2024/24InchTeddyBear-1734068311632.webp",
    description: `A lovable classic brown teddy bear with an adorable smile.
    Ultra-soft silky fur gives a warm and cozy feel.
    Perfect companion for bedtime stories and naps.
    Lightweight design makes it easy for kids to carry.
    Safe and child-friendly materials used throughout.`,
    price: "2499",
    rating: 4.8,
    reviews: 128,
    category: "Soft Toys",
  },
  {
    id: "st-002",
    name: "Rabbit Plush",
    image: "https://m.media-amazon.com/images/I/61VP9u-+3LL._AC_UF1000,1000_QL80_.jpg",
    description: `Cute rabbit plush with long floppy ears.
    Super soft texture perfect for hugging and cuddling.
    Made with hypoallergenic and safe materials.
    Gentle design suitable for toddlers and kids.
    Brings comfort during sleep and playtime.
    A lovely companion for everyday joy.`,
    price: "1999",
    rating: 4.6,
    reviews: 94,
    category: "Soft Toys",
  },
  {
    id: "st-003",
    name: "Dinosaur Toy",
    image: "https://static.wixstatic.com/media/333417_6485f8c0bb124b9ca50456010639cbba~mv2.jpg",
    description: `Colorful dinosaur plush for fun playtime.
    Soft and safe fabric perfect for kids.
    Encourages creativity and imagination.
    Lightweight and easy to carry anywhere.
    Perfect for both play and bedtime comfort.
    A must-have toy for dinosaur lovers.
    Brings excitement and joy to everyday play.`,
    price: "2799",
    rating: 4.9,
    reviews: 211,
    category: "Soft Toys",
  },
  {
    id: "st-004",
    name: "Elephant Soft Toy",
    image: "https://m.media-amazon.com/images/I/512qbv+3AfL._AC_UF1000,1000_QL80_.jpg",
    description: `Adorable elephant plush with soft finish.
    Smooth fabric gives a premium feel.
    Perfect for hugs, naps, and comfort.
    Cute design loved by kids instantly.
    Safe stitching and durable quality.
    Great addition to any toy collection.
    Provides comfort and warmth during bedtime.
    An ideal gift for kids who love cute animals.`,
    price: "2199",
    rating: 4.5,
    reviews: 76,
    category: "Soft Toys",
  },
  {
    id: "st-005",
    name: "Lion Plush",
    image: "https://www.ikea.com/in/en/images/products/djungelskog-soft-toy-lion__0710172_pe727375_s5.jpg",
    description: `Friendly lion plush with soft body.
    Designed for cuddles and playtime fun.
    Comfortable and gentle for kids.
    Perfect for storytelling and imagination.
    Strong stitching ensures long durability.
    A playful companion for everyday adventures.
    Encourages creative play and emotional bonding.`,
    price: "3299",
    rating: 4.0,
    reviews: 304,
    category: "Soft Toys",
  },

  {
    id: "st-006",
    name: "Koala Soft Toy",
    image: "https://images-cdn.ubuy.co.in/64132e2abf062028ce1cf2f1-koala-plush-toy-stuffed-animal-doll.jpg",
    description: `Cute koala plush with fluffy texture.
    Ultra-soft material for maximum comfort.
    Perfect for hugging and relaxing moments.
    Lightweight and easy for kids to carry.
    Safe and kid-friendly design.
    A lovable friend for all-day companionship.
    Great as a bedtime buddy for peaceful sleep`,
    price: "1899",
    rating: 4.4,
    reviews: 58,
    category: "Soft Toys",
  }
];

export default softToys;