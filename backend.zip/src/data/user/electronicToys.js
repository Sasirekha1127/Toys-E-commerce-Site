const electronicToys = [
  {
    id: "el-001",
    name: "Remote Control Car",
    image: "https://baybee.co.in/cdn/shop/files/71opsm_qR7L_1400x.jpg?v=1735995271",
    description: `High-speed remote control car for thrilling races.
    Smooth steering ensures easy control for kids.
    Durable wheels work on both indoor and outdoor surfaces.
    Perfect toy for exciting playtime and competitions.
    Built with strong materials for long-lasting use.
    Lightweight design makes it easy to carry anywhere.`,
    price: 4980,
    rating: 4.7,
    reviews: 267,
    category: "Electronic Toys",
    badge: "Glow in Dark",
    gradient: "toy-gradient-4"
  },
  {
    id: "el-002",
    name: "Drone",
    image: "https://www.ul.com/sites/default/files/styles/hero_boxed_width/public/2019-05/Image18_Quadcopter-drone_Caban_022819-Hero-1000x715.jpg?itok=6WSk4wNj",
    description: `Easy-to-fly drone with stable flight controls.
    Altitude hold feature helps beginners fly smoothly.
    Supports HD camera for fun aerial views.
    Great for outdoor adventures and learning flying skills.
    Compact design makes it easy to store and carry.
    Durable body ensures safe landing and flying.`,
    price: 6640,
    rating: 4.5,
    reviews: 198,
    category: "Electronic Toys",
    badge: "Editor's Pick",
    gradient: "toy-gradient-5"
  },
  {
    id: "el-003",
    name: "Robot Kit",
    image: "https://upload.wikimedia.org/wikipedia/commons/8/8c/Lego_Mindstorms_Nxt-FLL.jpg",
    description: `DIY robot kit for hands-on building experience.
    Includes motors and sensors for smart functionality.
    Encourages STEM learning and problem-solving skills.
    Perfect for creative kids who love engineering.
    Improves logical thinking and creativity.
    Easy-to-follow instructions for quick setup.`,
    price: 3730,
    rating: 4.8,
    reviews: 341,
    category: "Electronic Toys",
    badge: "Party Hit",
    gradient: "toy-gradient-6"
  },
  {
    id: "el-004",
    name: "Electronic Drum Set",
    image: "https://cdn.shopaccino.com/master-music/products/1-864460_m.jpg?v=684",
    description: `Fun electronic drum set with multiple sound modes.
    Built-in speakers give realistic music experience.
    Lightweight and easy to use for kids.
    Perfect toy to explore rhythm and music creativity.
    Includes demo beats for easy learning.
    Improves timing and musical skills.`,
    price: 4150,
    rating: 4.6,
    reviews: 155,
    category: "Electronic Toys",
    badge: "Super Scary",
    gradient: "toy-gradient-1"
  },
  {
    id: "el-005",
    name: "RC Helicopter",
    image: "https://m.media-amazon.com/images/I/71SRXsLCMxL.jpg",
    description: `Lightweight RC helicopter with stable flying control.
    Easy to operate even for beginners.
    Rechargeable battery for long playtime.
    Great toy for indoor flying fun and learning control.
    Compact design ensures safe indoor usage.
    Improves hand-eye coordination and control skills.`,
    price: 3320,
    rating: 4.9,
    reviews: 432,
    category: "Electronic Toys",
    badge: "⭐ Must Have",
    gradient: "toy-gradient-2"
  },
  {
    id: "el-006",
    name: "Smart Toy Dog",
    image: "https://contixo.com/cdn/shop/files/R3-Blue-Main-Image-111323.jpg?v=1753147236&width=1920",
    description: `Interactive smart dog that walks and barks.
    Responds to touch and performs fun actions.
    Engages kids with music and movement features.
    Perfect companion toy for fun and entertainment.
    Soft design makes it safe for kids.
    Encourages emotional bonding and play.`,
    price: 5810,
    rating: 4.7,
    reviews: 213,
    category: "Electronic Toys",
    badge: "STEM Kit",
    gradient: "toy-gradient-3"
  },
];

export default electronicToys;