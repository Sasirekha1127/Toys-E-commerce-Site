const educationalToys = [
  {
    id: "et-001",
    name: "Math Learning Blocks",
    image: "https://i0.wp.com/magrid.education/wp-content/uploads/2023/07/1.jpg",
    description: `Colorful math blocks for fun number learning.
    Helps kids understand counting and basic arithmetic.
    Encourages hands-on learning through play.
    Improves addition and subtraction skills easily.
    Bright colors attract kids' attention quickly.
    Enhances problem-solving and logical thinking.`,
    price: 1500,
    rating: 4.7,
    reviews: 189,
    category: "Educational Toys",
    badge: "Award Winner",
    gradient: "toy-gradient-2"
  },
  {
    id: "et-002",
    name: "Alphabet Puzzle",
    image: "https://m.media-amazon.com/images/I/712jYjZHrSL._AC_UF1000,1000_QL80_.jpg",
    description: `Fun alphabet puzzle for letter recognition.
    Helps kids learn A to Z in an engaging way.
    Improves vocabulary and memory skills.
    Encourages problem-solving through play.
    Colorful pieces keep kids interested.
    Enhances hand-eye coordination.
    Safe and durable design for kids.`,
    price: 2000,
    rating: 4.6,
    reviews: 147,
    category: "Educational Toys",
    badge: "STEM",
    gradient: "toy-gradient-3"
  },
  {
    id: "et-003",
    name: "Science Kit",
    image: "https://static.wixstatic.com/media/91210f_fc85cd488d314cf5bbe2798d63105167~mv2.webp/v1/fit/w_500,h_500,q_90/file.webp",
    description: `Exciting science kit with fun experiments.
    Encourages curiosity and discovery in kids.
    Includes safe materials for hands-on learning.
    Helps understand basic science concepts.
    Improves critical thinking skills.
    Engaging activities keep kids active.
    Supports STEM-based education.
    Perfect for young scientists.`,
    price: 1500,
    rating: 4.8,
    reviews: 223,
    category: "Educational Toys",
    badge: "Geography Fun",
    gradient: "toy-gradient-4"
  },
  {
    id: "et-004",
    name: "Magnetic Letters",
    image: "https://thetypesetco.com/cdn/shop/files/3E8CB307-B8BC-4615-8A28-101624BA27D4.png?v=1744201649&width=1080",
    description: `Magnetic letters for easy word learning.
    Can be used on boards and fridge surfaces.
    Helps kids practice spelling and vocabulary.
    Encourages word formation skills.
    Bright colors make learning fun.
    Reusable and easy to handle pieces.
    Improves language and reading ability.
    Perfect for home learning.`,
    price: 1800,
    rating: 4.9,
    reviews: 316,
    category: "Educational Toys",
    badge: "Top Rated",
    gradient: "toy-gradient-5"
  },
  {
    id: "et-005",
    name: "Shape Sorting Cube",
    image: "https://us.bababooandfriends.com/cdn/shop/products/KB110041_ShapeSorterCube_Life_P02LowRes.jpg?v=1734445926&width=1080",
    description: `Interactive cube for learning shapes and colors.
    Helps improve sorting and matching skills.
    Enhances hand-eye coordination.
    Encourages logical thinking development.
    Bright design keeps kids engaged.
    Safe and sturdy construction.
    Boosts early cognitive skills.
    Ideal toy for toddlers.`,
    price: 2000,
    rating: 4.7,
    reviews: 188,
    category: "Educational Toys",
    badge: "Future Tech",
    gradient: "toy-gradient-6"
  },
  {
    id: "et-006",
    name: "Counting Beads Abacus",
    image: "https://bluebellstoys.com/wp-content/uploads/2024/06/Abacus-3-12.webp",
    description: `Classic abacus for learning numbers and counting.
    Helps kids understand addition and patterns.
    Builds strong math fundamentals early.
    Easy-to-use sliding bead design.
    Improves focus and concentration.
    Enhances logical thinking skills.
    Durable and safe for daily use.
    Perfect educational tool for kids.`,
    price: 1700,
    rating: 4.5,
    reviews: 104,
    category: "Educational Toys",
    gradient: "toy-gradient-1"
  },
];

export default educationalToys;