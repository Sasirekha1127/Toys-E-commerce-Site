import softToys from './softToys';
import educationalToys from './educationalToys';
import electronicToys from './electronicToys';

export const allProducts = [...softToys, ...educationalToys, ...electronicToys];

export { softToys, educationalToys, electronicToys };
