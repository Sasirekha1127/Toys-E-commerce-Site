import React from 'react';
import { Routes, Route } from 'react-router-dom';
import  {StoreProvider } from './context/StoreContext.jsx';
import { AdminProvider } from './context/AdminContext.jsx';
import UserLayout from './layouts/UserLayout';
import AdminLayout from './layouts/AdminLayout';
import SellerLayout from './layouts/SellerLayout';

import Home from './pages/user/Home';
import Cart from './pages/user/Cart';
import Wishlist from './pages/user/Wishlist';
import ProductDetails from './pages/user/ProductDetails';
import AuthPage from './pages/user/AuthPage';
import CheckoutPage from './pages/user/CheckoutPage';

import Dashboard from './pages/admin/Dashboard';
import Products from './pages/admin/Products';
import Orders from './pages/admin/Orders';
import Customers from './pages/admin/Customers';
import Inventory from './pages/admin/Inventory';
import Settings from './pages/admin/Settings';
import Categories from './pages/admin/Categories';
import Reviews from './pages/admin/Reviews';
import Offers from './pages/admin/Offers';

import SellerDashboard from './pages/seller/Dashboard';
import SellerProducts from './pages/seller/Products';
import SellerOrders from './pages/seller/Orders';
import SellerInventory from './pages/seller/Inventory';
import SellerReviews from './pages/seller/Reviews';
import SellerProfile from './pages/seller/Profile';

export default function App() {
  return (
    <StoreProvider>
      <Routes>
          {/* Auth as default */}
          <Route path="/" element={<AuthPage />} />
          <Route path="/auth" element={<AuthPage />} />

          {/* User */}
          <Route path="/home" element={<UserLayout><Home /></UserLayout>} />
          <Route path="/product/:id" element={<UserLayout><ProductDetails /></UserLayout>} />
          <Route path="/cart" element={<UserLayout><Cart /></UserLayout>} />
          <Route path="/wishlist" element={<UserLayout><Wishlist /></UserLayout>} />
          <Route
            path="/checkout"
            element={
              <UserLayout>
                <CheckoutPage />
              </UserLayout>
            }
          />

          {/* Admin */}
          <Route path="/admin" element={<AdminProvider><AdminLayout><Dashboard /></AdminLayout></AdminProvider>} />
          <Route path="/admin/products" element={<AdminProvider><AdminLayout><Products /></AdminLayout></AdminProvider>} />
          <Route path="/admin/orders" element={<AdminProvider><AdminLayout><Orders /></AdminLayout></AdminProvider>} />
          <Route path="/admin/customers" element={<AdminProvider><AdminLayout><Customers /></AdminLayout></AdminProvider>} />
          <Route path="/admin/inventory" element={<AdminProvider><AdminLayout><Inventory /></AdminLayout></AdminProvider>} />
          <Route path="/admin/settings" element={<AdminProvider><AdminLayout><Settings /></AdminLayout></AdminProvider>} />
          <Route path="/admin/categories" element={<AdminProvider><AdminLayout><Categories /></AdminLayout></AdminProvider>} />
          <Route path="/admin/reviews" element={<AdminProvider><AdminLayout><Reviews /></AdminLayout></AdminProvider>} />
          <Route path="/admin/offers" element={<AdminProvider><AdminLayout><Offers /></AdminLayout></AdminProvider>} />
          

          {/* Seller */}
          <Route path="/seller" element={<SellerLayout><SellerDashboard /></SellerLayout>} />
          <Route path="/seller/products" element={<SellerLayout><SellerProducts /></SellerLayout>} />
          <Route path="/seller/orders" element={<SellerLayout><SellerOrders /></SellerLayout>} />
          <Route path="/seller/inventory" element={<SellerLayout><SellerInventory /></SellerLayout>} />
          <Route path="/seller/reviews" element={<SellerLayout><SellerReviews /></SellerLayout>} />
          <Route path="/seller/profile" element={<SellerLayout><SellerProfile /></SellerLayout>} />
      </Routes>
    </StoreProvider>
  );
}