import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import defaultUsers from '../../../data/user/user';

function Field({ label, error, children }) {
  return (
    <div className="space-y-1.5">
      {label && <label className="text-sm font-semibold text-gray-700">{label}</label>}
      {children}
      {error && <p className="text-xs text-red-500 font-medium">{error}</p>}
    </div>
  );
}

export default function UserLoginForm({
  onSwitchToSellerLogin,
  onSwitchToSellerRegister,
  onSwitchToUserRegister,
}) {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState({});
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const set = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));

    if (errors[key] || errors.general) {
      setErrors((prev) => ({ ...prev, [key]: '', general: '' }));
    }
  };

  const validate = () => {
    const err = {};

    if (!form.email.trim()) {
      err.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      err.email = 'Enter a valid email';
    }

    if (!form.password) {
      err.password = 'Password is required';
    }

    return err;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const err = validate();
    if (Object.keys(err).length) {
      setErrors(err);
      return;
    }

    const emailNorm = form.email.trim().toLowerCase();
    const password = form.password;

    //  ADMIN
    if (emailNorm === 'sasi@gmail.com' && password === 'Sasi@1234') {
      localStorage.removeItem('toyCurrentSeller');
      localStorage.setItem(
        'toyCurrentUser',
        JSON.stringify({
          role: 'admin',
          name: 'Admin',
          email: 'sasi@gmail.com',
        })
      );
      navigate('/admin');
      return;
    }

    //  SELLER
    const sellers = JSON.parse(localStorage.getItem('toySellers') || '[]');

    const matchedSeller = sellers.find(
      (seller) =>
        seller.email?.toLowerCase() === emailNorm &&
        seller.password === password
    );

    if (matchedSeller) {
      setLoading(true);

      setTimeout(() => {
        localStorage.removeItem('toyCurrentUser');
        localStorage.setItem(
          'toyCurrentSeller',
          JSON.stringify({
            role: 'seller',
            ...matchedSeller,
          })
        );
        setLoading(false);
        navigate('/seller');
      }, 1000);

      return;
    }

    //  USER (JSON + registered)
    const localUsers = JSON.parse(localStorage.getItem('toyUsers') || '[]');
    const allUsers = [...defaultUsers, ...localUsers];

    console.log("All users:", allUsers);
    console.log("Entered:", emailNorm, password);

    const matchedUser = allUsers.find(
      (user) =>
        user.email?.toLowerCase() === emailNorm &&
        user.password === password
    );

    if (!matchedUser) {
      setErrors({ general: 'Invalid email or password' });
      return;
    }

    setLoading(true);

    setTimeout(() => {
      localStorage.removeItem('toyCurrentSeller');
      localStorage.setItem(
        'toyCurrentUser',
        JSON.stringify({
          role: 'user',
          id: matchedUser.id || null,
          name: matchedUser.name,
          email: matchedUser.email,
        })
      );
      setLoading(false);
      navigate('/home');
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5" noValidate>
      <Field label="Email Address" error={errors.email}>
        <input
          type="email"
          value={form.email}
          onChange={(e) => set('email', e.target.value)}
          placeholder="you@example.com"
          className="auth-input"
        />
      </Field>

      <Field label="Password" error={errors.password}>
        <div className="relative">
          <input
            type={showPass ? 'text' : 'password'}
            value={form.password}
            onChange={(e) => set('password', e.target.value)}
            placeholder="••••••••"
            className="auth-input pr-11"
          />
          <button
            type="button"
            onClick={() => setShowPass((prev) => !prev)}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-orange-500 text-xs font-semibold"
          >
            {showPass ? 'Hide' : 'Show'}
          </button>
        </div>
      </Field>

      {errors.general && (
        <p className="text-sm text-red-500 text-center">{errors.general}</p>
      )}

      <button type="submit" disabled={loading} className="auth-btn-primary">
        {loading ? 'Signing in…' : 'Sign In to ToyStore 🛒'}
      </button>

      <div className="pt-1 text-center space-y-2">
        <button
          type="button"
          onClick={onSwitchToUserRegister}
          className="block w-full text-sm font-semibold text-orange-600"
        >
          Create User Account
        </button>

        <button
          type="button"
          onClick={onSwitchToSellerRegister}
          className="block w-full text-sm font-semibold text-gray-500"
        >
          Seller Register
        </button>
      </div>
    </form>
  );
}