import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  ShoppingCart,
  Heart,
  Menu,
  X,
  User,
} from "lucide-react";
import { useStore } from "../../context/StoreContext";

export default function Header({ onCategoryChange, onSearch }) {
  const { cartCount, wishlist } = useStore();
  const navigate = useNavigate();
  const location = useLocation();

  const [input, setInput] = useState("");
  const handleInput = (e) => {
    setInput(e.target.value);
    onSearch?.(e.target.value);
  };

  const [showOffer, setShowOffer] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [searchTerm, setSearchTerm] = useState("");
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const profileRef = useRef(null);
  const categoryRef = useRef(null);

  const categories = ["All Categories", "Soft Toys", "Educational Toys", "Electronic Toys"];
  const isHomePage = location.pathname === "/" || location.pathname === "/home";

  useEffect(() => {
    if (!isHomePage) return;

    const handleScroll = () => setShowOffer(window.scrollY <= 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [isHomePage]);

  useEffect(() => {
    if (isHomePage) {
      setShowOffer(window.scrollY <= 50);
    } else {
      setShowOffer(false);
      setMobileMenuOpen(false);
      setCategoryDropdownOpen(false);
    }
  }, [isHomePage]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (categoryRef.current && !categoryRef.current.contains(event.target)) {
        setCategoryDropdownOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleCategorySelect = (cat) => {
    setSelectedCategory(cat);
    setCategoryDropdownOpen(false);
    onCategoryChange?.(cat);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    onSearch?.(value);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-white ">
      {/* Offer Bar - Home page only */}
      {isHomePage && (
        <div
          className={`bg-orange-500 text-white text-center text-sm font-semibold overflow-hidden transition-all duration-300 ${showOffer ? "max-h-10 py-2 opacity-100" : "max-h-0 py-0 opacity-0"
            }`}
        >
          Flat 20% OFF on Soft Toys | Instend Delivery
        </div>
      )}
      {/* Navbar */}
      <nav className="shadow-sm sticky top-0 z-50 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl flex items-center justify-center shadow-toy group-hover:shadow-toy-hover transition-all duration-300 group-hover:scale-105 group-hover:rotate-3">
              <span className="text-white text-xl">🧸</span>
            </div>
            <div>
              <span className="font-bold text-2xl text-orange-600">ToyStore</span>
              <div className="flex items-center gap-1 -mt-1"></div>
            </div>
          </Link>

          {/* Desktop Search + Category - Home page only */}
          {isHomePage && (
            <div
              className="hidden md:flex flex-1 max-w-md mx-4 items-center gap-2 relative"
              ref={categoryRef}
            >
              <button
                className={`flex items-center gap-2 border rounded px-4 py-2 text-sm transition-all
                  ${selectedCategory === "All Categories"
                    ? "bg-orange-100 border-orange-400 text-orange-600"
                    : "bg-gray-100 border-gray-300 text-gray-700 hover:bg-orange-50"
                  }`}
                onClick={() => setCategoryDropdownOpen(!categoryDropdownOpen)}
              >
                <span className="truncate max-w-[140px]">{selectedCategory}</span>
                <X size={14} className={`${categoryDropdownOpen ? "rotate-45" : ""}`} />
              </button>

              {categoryDropdownOpen && (
                <ul className="absolute top-full left-0 mt-1 text-sm w-38 bg-white border rounded shadow-md z-50">
                  {categories.map((cat, idx) => (
                    <li
                      key={idx}
                      className="px-7 py-2 hover:bg-orange-100 cursor-pointer"
                      onClick={() => handleCategorySelect(cat)}
                    >
                      {cat}
                    </li>
                  ))}
                </ul>
              )}

              <input
                type="text"
                placeholder="Search toys..."
                value={input}
                onChange={handleInput}
                className="border p-2 rounded w-full focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          )}

          <div className="flex items-center gap-3">
            {/* Wishlist */}
            <div
              className="relative cursor-pointer"
              onClick={() => navigate("/wishlist")}
            >
              <Heart
                className="text-gray-500 hover:text-orange-400 transition-colors duration-200"
                size={20}
              />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-400 text-white text-[10px] px-1 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </div>

            {/* Cart */}
            <div
              className="relative cursor-pointer"
              onClick={() => navigate("/cart")}
            >
              <ShoppingCart
                className="text-gray-500 hover:text-orange-400 transition-colors duration-200"
                size={20}
              />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-400 text-white text-[10px] px-1 rounded-full flex items-center justify-center">
                  {cartCount > 9 ? "9+" : cartCount}
                </span>
              )}
            </div>

            {/* Profile */}
            <div className="relative" ref={profileRef}>
              <button
                type="button"
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="text-gray-500 hover:text-orange-400 transition-colors duration-200"
              >
                <User size={20} />
              </button>

              {profileDropdownOpen && (
                <div className="absolute right-0 top-8 w-48 bg-white border border-gray-100 rounded-xl shadow-lg py-2 z-50">
                  {(() => {
                    const currentUser = JSON.parse(localStorage.getItem("toyCurrentUser") || "null");
                    const currentSeller = JSON.parse(localStorage.getItem("toyCurrentSeller") || "null");

                    if (currentUser && currentUser.role === 'user') {
                      return (
                        <>
                          <div className="px-4 py-3 border-b border-gray-100">
                            <p className="text-sm font-semibold text-gray-800">{currentUser.email}</p>
                            <p className="text-xs text-gray-500">User Account</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              localStorage.removeItem("toyCurrentUser");
                              window.location.href = '/auth';
                            }}
                            className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-500 transition"
                          >
                            Logout
                          </button>
                        </>
                      );
                    } else if (currentSeller) {
                      return (
                        <>
                          <div className="px-4 py-3 border-b border-gray-100">
                            <p className="text-sm font-semibold text-gray-800">{currentSeller.sellerName}</p>
                            <p className="text-xs text-gray-500">{currentSeller.shopName}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigate("/seller");
                              setProfileDropdownOpen(false);
                            }}
                            className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-500 transition"
                          >
                            Seller Dashboard
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              localStorage.removeItem("toyCurrentSeller");
                              window.location.href = '/auth';
                            }}
                            className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-500 transition"
                          >
                            Logout
                          </button>
                        </>
                      );
                    } else {
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            navigate("/auth");
                            setProfileDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-orange-50 hover:text-orange-500 transition"
                        >
                          Sign In
                        </button>
                      );
                    }
                  })()}
                </div>
              )}
            </div>

            {/* Mobile Menu Button - Home page only */}
            {isHomePage && (
              <button
                type="button"
                className="md:hidden w-10 h-10 flex items-center justify-center rounded-xl text-gray-600 hover:bg-orange-50 hover:text-orange-500 transition-all"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            )}
          </div>
        </div>

        {/* Mobile Menu - Home page only */}
        {isHomePage && mobileMenuOpen && (
          <div className="md:hidden px-4 pb-4 space-y-3 bg-white">
            <select
              value={selectedCategory}
              onChange={(e) => handleCategorySelect(e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              {categories.map((cat, idx) => (
                <option key={idx}>{cat}</option>
              ))}
            </select>

            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-orange-500"
            />
          </div>
        )}
      </nav>
    </header>
  );
}